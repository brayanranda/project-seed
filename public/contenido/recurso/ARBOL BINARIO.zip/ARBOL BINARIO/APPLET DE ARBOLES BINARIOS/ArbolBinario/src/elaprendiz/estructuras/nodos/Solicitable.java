package elaprendiz.estructuras.nodos;

public interface Solicitable {

  boolean menorQue(Solicitable object);
  boolean mayorQue(Solicitable object);
  boolean igual(Solicitable object);

}
