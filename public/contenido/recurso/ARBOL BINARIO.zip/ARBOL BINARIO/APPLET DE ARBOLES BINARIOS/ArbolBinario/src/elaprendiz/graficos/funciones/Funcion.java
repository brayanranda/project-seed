package elaprendiz.graficos.funciones;

import java.util.Observable;
import java.util.Observer;

public abstract class Funcion extends Observable {

  protected boolean terminado = false;

  public boolean funcionTerminada() {
    return terminado;
  }

  public abstract void performFuncion();
}

